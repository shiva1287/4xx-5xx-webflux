package com.reactivespring.controller;

public class MoviesControllerIntgTest {
}
